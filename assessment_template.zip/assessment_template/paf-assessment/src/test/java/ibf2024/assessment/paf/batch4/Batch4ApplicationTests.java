package ibf2024.assessment.paf.batch4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Batch4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
