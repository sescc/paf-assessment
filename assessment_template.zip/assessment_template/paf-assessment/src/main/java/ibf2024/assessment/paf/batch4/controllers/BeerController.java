package ibf2024.assessment.paf.batch4.controllers;

public class BeerController {

	//TODO Task 2 - view 0
	
	
	//TODO Task 3 - view 1
	

	//TODO Task 4 - view 2

	
	//TODO Task 5 - view 2, place order

}
