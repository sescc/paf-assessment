package ibf2024.assessment.paf.batch4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Batch2Application {

	public static void main(String[] args) {
		SpringApplication.run(Batch2Application.class, args);
	}

}
